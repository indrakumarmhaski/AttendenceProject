
<?php
session_start();

if(! isset($_SESSION['username']) && ! isset($_SESSION['password']))
{
    header('location:attendence.html');
}
$username=$_SESSION['username'];
$password=$_SESSION['password'];
$table=$username.$password;
$month='July';

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'attendence');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="css/mainpagestyle.css" rel="stylesheet">
    <link rel="stylesheet" href="node_modules\bootstrap\dist\css\bootstrap.min.css"> 
</head>
<body>

<!-- Starting navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 <span id="contect_us">Contect Us</span>
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <p class="dropdown-item">Mob no. 8770734350</p>
                <div class="dropdown-divider"></div>
                <p class="dropdown-item" >indrakumarmhaski@gmail.com</p>
              </div>
            </li>
            <li class="nav-item" id="log_container" >
                <a style="color:white;" href="logout.php">Logout</a>
            </li>
            <li class="nav-item" id="be_container">
              <span>Be digital, Be smart</span>
            </li>
           </ul>
        </div>
 </nav>
      <!-- The end of navbar -->

<div class="container-fluid" >

<div class="row">  <!-- Row for photo months and table form  -->
         <div class="col-lg-2" style="background-color:lavender; height:723px;">
         <?php
           $forimage="select image from user where username='$username' and password='$password' ";
           $result=mysqli_query($con,$forimage);
           $imgData=mysqli_fetch_array($result);
           echo '<img style="height:200px" class="img-thumbnail img-fluid" alt="Profile Image" src="data:image/jpeg;base64,'.base64_encode( $imgData['image'] ).'"/>';
         ?> 
         <h3 style="text-align: center;"> <br><?php echo $username ?></h3>
         <h5>Date: <?php echo date("Y-m-d") ?></h5>
 
         <div class="list-group" style="overflow-y: scroll; height:300px;">
            <a href="testing.php"class="list-group-item list-group-item-action">January</a>
            <a href="tfeb.php" class="list-group-item list-group-item-action">February</a>
            <a href="tmar.php" class="list-group-item list-group-item-action">March</a>
            <a href="tapr.php" class="list-group-item list-group-item-action">April</a>
            <a href="tmay.php" class="list-group-item list-group-item-action">May</a>
            <a href="tjun.php" class="list-group-item list-group-item-action">June</a>
            <a href="tjul.php" class="list-group-item active">July</a>
            <a href="taug.php" class="list-group-item list-group-item-action">August</a>
            <a href="tsep.php" class="list-group-item list-group-item-action">september</a>
            <a href="toct.php" class="list-group-item list-group-item-action">October</a>
            <a href="tnov.php" class="list-group-item list-group-item-action">November</a>
            <a href="tdec.php" class="list-group-item list-group-item-action">December</a>
         </div>

        </div>  <!-- End of the div used for photo and date -->

<!-- Starting the div used for form , table -->
<div class="col-lg-10" style="padding-right:0px;padding-left:0px; background-color: lavender;">
 
<div style="background-color: lavender; overflow-y: scroll;height:550px;">

<form action="insertattendence.php" method="post">  <!-- Starting of the form -->

<table class="">
    <tr>
        <th style="text-align:center" >date</th>
        <th style="text-align:center">day</th>
        <th style="text-align:center">frist half</th>
        <th style="text-align:center">p1</th>
        <th style="text-align:center">p2</th>
        <th style="text-align:center">p3</th>
    </tr>
  
        <?php
            $q="select * from $table where month='$month' order by id ";
            $r=mysqli_query($con,$q);
            $num=mysqli_num_rows($r);
        for($i=1;$i<=$num;$i++)
        {
            $arr=mysqli_fetch_array($r); 
        ?>
        <tr style="font-size:18px ">   
        <td class="date"> <?php echo $arr['date'] ?> </td>
        <td> <?php echo $arr['day'] ?> </td>
        <?php
           if($arr['date']==date("Y-m-d") && $arr['day'] != 'Sunday')
           {
               $_SESSION['toupdateid']=$arr['id'];
               $_SESSION['month']=$month;
        ?>
        <td> <input  type="text" name="first_half" value="<?php echo $arr['first_half'] ?>" ></td>
        <td> <input type="text" name="p_one" value="<?php echo $arr['p_one'] ?>" > </td>
        <td> <input type="text" name="p_two" value="<?php echo $arr['first_half'] ?>" > </td>
        <td> <input type="text" name="p_three" value="<?php echo $arr['first_half'] ?>" > </td>
        
        <?php
           }
        else if($arr['day']=='Sunday')
        {  
        ?>
           <td > <h3 class="sun"> <?php echo $arr['first_half'] ?> </h3> </td>
           <td> <h3 class="sun"> <?php echo $arr['p_one'] ?> </h3> </td>
           <td> <h3 class="sun"> <?php echo $arr['p_two'] ?> </h3> </td>
           <td> <h3 class="sun"> <?php echo $arr['p_three'] ?> </h3> </td>
        
        <?php
        }
        else
        {
        ?>
        <td > <?php echo $arr['first_half'] ?> </td>
        <td> <?php echo $arr['p_one'] ?> </td>
        <td> <?php echo $arr['p_two'] ?> </td>
        <td> <?php echo $arr['p_three'] ?> </td>
        </tr>
        <?php
         }
        }
        ?>
</table>
    </div>
        <input type="submit" style="background-color: blue; color: white;width: 95px;border-radius: 16px;margin-top: 15px;margin-left: 950px;height:34px;" value="Submit">
      </form>

    </div>  <!-- End of the div used for form , table -->
</div>   <!-- End of div used as first row in which there are both photo and table -->







    </div>   <!-- End of the container div -->
<!-- Starting of foter -->

<blockquote class="blockquote text-right" style="background-color: gainsboro; margin-bottom: 0px;">

        <p class="mb-0">We are porviding you the survise to keep your attendence safe and 
            be intractive with your attendence.
        </p>
        <footer class="blockquote-footer" style="color: black; font-weight: bold; " >
            <cite style="margin-right:10px;" title="Source Title">Mr.I.K.MHASKI</cite>
        </footer>
</blockquote>

<!-- End of footer -->

    <script src="jquery\jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="node_modules\bootstrap\dist\js\bootstrap.min.js"></script>    
</body>
</html> 