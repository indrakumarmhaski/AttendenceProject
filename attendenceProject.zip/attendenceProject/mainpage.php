
<?php
session_start();
$username=$_SESSION['username'];
$password=$_SESSION['password'];

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'attendence');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="css/mainpagestyle.css" rel="stylesheet">
    <link rel="stylesheet" href="node_modules\bootstrap\dist\css\bootstrap.min.css"> 
</head>
<body>

<!-- Starting navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 <span id="contect_us">Contect Us</span>
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <p class="dropdown-item">Mob no. 8770734350</p>
                <div class="dropdown-divider"></div>
                <p class="dropdown-item" >indrakumarmhaski@gmail.com</p>
              </div>
            </li>
            <li class="nav-item" id="be_container">
              <span>Be digital, Be smart</span>
            </li>
           </ul>
        </div>
 </nav>
      <!-- The end of navbar -->
















<!-- Starting of foter -->

<blockquote class="blockquote text-right">
        <p class="mb-0">We are porviding you the survise to keep your attendence safe and 
            be intractive with your attendence.
        </p>
        <footer class="blockquote-footer">
            <cite style="margin-right:10px;" title="Source Title">Mr.I.K.MHASKI</cite>
        </footer>
</blockquote>

<!-- End of footer -->

    <script src="jquery\jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="node_modules\bootstrap\dist\js\bootstrap.min.js"></script>    
</body>
</html>