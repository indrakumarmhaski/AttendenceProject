<?php
session_start();
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'nots');
if( !isset($_SESSION['username']) || !isset($_SESSION['password']) )
{
    header('location:nots.html');
}
$username=$_SESSION['username'];
$password=$_SESSION['password'];
$forimage="select photo from user where name='$username' and password='$password' ";
$foroldnots="select nots,time from userdata where name='$username' and password='$password' ";
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="css/notsstyle.css" rel="stylesheet">
        <link rel="stylesheet" href="node_modules\bootstrap\dist\css\bootstrap.min.css">
        <script>
            function validat()
            {
                var result=true;
                var i=document.getElementsByName("nots");
                if(i[0].value.length==0)
                {
                    alert('Please Write something');
                    result=false;
                }
                return(result);
            }
        </script>
    </head>
    <body>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                   <div class="collapse navbar-collapse" id="navbarSupportedContent">
                   <ul class="navbar-nav mr-auto">
                   <li class="nav-item active">
                   <li class="nav-item dropdown">
                   <a  class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:  white;">
                             Contect Us
                   </a>
                   <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                   <h5 class="dropdown-item">8770734350</h5>
                   <div class="dropdown-divider"></div>
                   <p class="dropdown-item">indrakumarmhaski@gmail.com</p>
                   </div>
                   </li>
                   </ul>
                   <h5 style="margin-right:14px; color:white;"><a style="color:white;" href="logout.php">LogOut</a></h5>
                   <h4 style="color:aqua;">Enjoy Nots</h4>
                   </div>
            </nav>

<div class="container-fluid">
     <div class="row">
         <div class="col-lg-2" style="background-color:lavender;">
         <?php
           $result=mysqli_query($con,$forimage);
           $imgData=mysqli_fetch_array($result);
           echo '<img style="height:230px" class="img-thumbnail img-fluid" alt="Profile Image" src="data:image/jpeg;base64,'.base64_encode( $imgData['photo'] ).'"/>';
         ?> 
         <h4 style="text-align: center;"> <br><?php echo $username ?></h4>
         <br>
         <h5>Date: <?php echo date("Y-m-d") ?></h5>
  
        </div>

         <div class="col-lg-10" style="background-color:orange; overflow-y: scroll; height:378px;">
            <?php
                  $nots=mysqli_query($con,$foroldnots);
                  $num=mysqli_num_rows($nots);
                  if($num==0)
                     echo ' <h3 style="text-align:center; margin-top:150px;">No privious nots exists.</h3> ';
                  for($i=1;$i<=$num;$i++)
                  {
                      $arr=mysqli_fetch_array($nots);
            ?>
                       <h5><?php echo $arr['nots'] ?></h5>
                       <h6><?php echo $arr['time'] ?></h2>
                       <hr>
            <?php
                  }
            ?>
         </div>
    </div>
    <div class="row">
       <div class="col-lg-12" style="background-color:skyblue; padding-bottom: 7px;">
            <form action="insertuserdata.php" method="post" onsubmit="return validat()">
              <h3>Write nots here.</h3>
                <textarea name="nots" cols="184" rows="5"></textarea>
                <input class="btn btn-primary" style="width: 91px;margin-left: 31px;" type="submit" value="Add">
                <input class="btn btn-danger" style="width: 91px; margin-left:18px;" type="reset" value="Reset">
            </form>
       </div>
    </div>
</div>
    
    <footer>
        <blockquote class="blockquote">
            <p class="mb-0">You don't need to remember improtrant things, let them remembered by NOTS.</p>
            <div style="float: right; margin-right:5px; background-color:gainsboro;" class="blockquote-footer ikm ">Mr. <cite title="Source Title">Indra Kumar Mhaski</cite></div>
          </blockquote>
    </footer>
        <script src="jquery\jquery.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="node_modules\bootstrap\dist\js\bootstrap.min.js"></script>
    </body>
</html>

<?php
mysqli_close($con);
?>