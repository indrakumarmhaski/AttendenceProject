<!DOCTYPE html>
<!-- This is the signup Page of this application
     Which comes after loginpage if someone chooses to
     signup. After this page you will jumped to the adduser
     where the logic to add a user in db is written if that success
    the that will thro you to loginpage   -->
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="css/formstyle.css" rel="stylesheet">
        <link rel="stylesheet" href="node_modules\bootstrap\dist\css\bootstrap.min.css"> 
        <script>
            // This is the logic for form validation.
            function formvalidat()
            {
                var result=true;
                var i=document.getElementsByName("username");
                var j=document.getElementsByName("password");
                if(i[0].value.length==0)
                {
                    alert('Please Enter Username');
                    result=false;
                }
                else if(j[0].value.length==0)
                {
                    alert('Please Enter Password');
                    result=false;
                }
                return(result);
            }
        </script>
    </head>
    <body>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                   <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                        <li class="nav-item dropdown">
                          <a  class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:  white;">
                             Contect Us
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <h5 class="dropdown-item">8770734350</h5>
                            <div class="dropdown-divider"></div>
                            <p class="dropdown-item">indrakumarmhaski@gmail.com</p>
                          </div>
                        </li>
                      </ul>
                      <h4 style="color:aqua;">Enjoy Nots</h4>
                    </div>
                  </nav>
    <div class="container outer-body">
              <h3 id="heading">SignUp Form</h3>
        <div id="form-container">
             
        <!-- Form, sends data to adduer.php page -->
            <form action="adduser.php" method="post" onsubmit="return formvalidat()" enctype="multipart/form-data">
               <br> <br>
               <label class="glyphicon glyphicon-user" >Username:</label> 
               <input type="text" name="username">   <br> <br>
               <label >Password: </label>
               <input style="margin-left: 4px;" type="password" name="password">
               <br>
               <label >Profile Image:</label>
               <input type="file" name="image">  <br>
               <input type="submit" value="SignUp" class="btn btn-primary" style="margin-left: 156px;
               height: 29px;padding-top: 1px;">
               <input type="reset" value="Reset" class="btn btn-danger" style="height: 29px;padding-top: 1px;">
               <br>
               <a href="nots.html" style="float: right; margin-right: 12px;">Cancle</a>
              
            </form>


        </div>


    </div>
    
    <footer>
        <blockquote class="blockquote">
            <p class="mb-0">You don't need to remember improtrant things, let them remembered by NOTS.</p>
            <div style="float: right; margin-right:5px; background-color:gainsboro;" class="blockquote-footer ikm ">Mr. <cite title="Source Title">Indra Kumar Mhaski</cite></div>
          </blockquote>
    </footer>
        <script src="jquery\jquery.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="node_modules\bootstrap\dist\js\bootstrap.min.js"></script>
    </body>
</html>