<?php
session_start();

if(! isset($_SESSION['username']) && ! isset($_SESSION['password']) && !isset($_SESSION['toupdateid']) )
{
    header('location:attendence.html');
}

$username=$_SESSION['username'];
$password=$_SESSION['password'];
$table=$username.$password;
$month=$_SESSION['month'];
$id=$_SESSION['toupdateid'];
$firsthalf=$_POST['first_half'];
$p_one=$_POST['p_one'];
$p_two=$_POST['p_two'];
$p_three=$_POST['p_three'];

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'attendence');

$q="update $table set first_half='$firsthalf',
 p_one='$p_one', p_two='$p_two', p_three='$p_three'
 where id=$id ";

 $res=mysqli_query($con,$q);

 if($res==1)
 {
     header('location:testing.php');
 }
 else
 {
     echo "Some error";
 }

 ?>