<?php
session_start();

$username=$_POST['username'];
$password=$_POST['password'];

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'attendence');
$q="select username from user where username='$username' and password='$password' ";
$r=mysqli_query($con,$q);
$num=mysqli_num_rows($r);
if($num==1)
{
    $_SESSION['username']=$username;
    $_SESSION['password']=$password;
    header('location:testing.php');
}
    
else
{
    header('location:notauser.php');
}


mysqli_close($con);
?>