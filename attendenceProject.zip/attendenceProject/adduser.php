<?php

$username=$_POST['username'];
$password=$_POST['password'];
$table=$username.$password;
$photo=$_FILES['photo']['tmp_name'];

if($_FILES['photo']['type'] != 'image/jpeg')
{
    header('location:nojpeg.php');
}
$imageContent=addslashes(file_get_contents($photo));

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'attendence');
$q="select username from user where username='$username' and password='$password' ";
$r=mysqli_query($con,$q);
$num=mysqli_num_rows($r);

if($num==1)
{
    header('location:upexist.php');
}

else
{
    $qu="insert into user (username,password,image) values ('$username','$password','$imageContent') ";
    $re=mysqli_query($con,$qu);
    $que="create table $table(id int(4) PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(90) DEFAULT '$username' ,password VARCHAR(20) DEFAULT '$password',
    month VARCHAR(20),
    first_half VARCHAR(5) DEFAULT '-',p_one VARCHAR(5) DEFAULT '-',p_two VARCHAR(5) DEFAULT '-',
    p_three VARCHAR(5) DEFAULT '-',
    date DATE,day VARCHAR(20) )";
    mysqli_query($con,$que);

    // Declaration of days variables
    $mon='Monday';
    $tue='Tuesday';
    $wed='Wednesday';
    $thur='Thursday';
    $fri='Friday';
    $set='Seterday';
    $sun='Sunday';

    $feb='February';
    $mar='March';
    $apr='April';
    $may='May';
    $jun='June';
    $jul='July';
    $aug='August';
    $sep='September';
    $oct='October';
    $nov='November';
    $des='December';

    // Creating database for january
    $forjan1="insert into $table(month,date,day) values 
    ('January','2018-01-01','$mon'), 
    ('January','2018-01-02','$tue'),  
    ('January','2018-01-03','$wed'),  
    ('January','2018-01-04','$thur'), 
    ('January','2018-01-05','$fri'),
    ('January','2018-01-06','$set'),
    ('January','2018-01-07','$sun'),
    ('January','2018-01-08','$mon'),
    ('January','2018-01-09','$tue'),
    ('January','2018-01-10','$wed'),
    ('January','2018-01-11','$thur'),
    ('January','2018-01-12','$fri'),
    ('January','2018-01-13','$set'),
    ('January','2018-01-14','$sun') ";
    $forjan2="insert into $table(month,date,day) values
    ('January','2018-01-15','$mon'),
    ('January','2018-01-16','$tue'),
    ('January','2018-01-17','$wed'),
    ('January','2018-01-18','$thur'),
    ('January','2018-01-19','$fri'),
    ('January','2018-01-20','$set'),
    ('January','2018-01-21','$sun'),
    ('January','2018-01-22','$mon'),
    ('January','2018-01-23','$tue'),
    ('January','2018-01-24','$wed'),
    ('January','2018-01-25','$thur'),
    ('January','2018-01-26','$fri'),
    ('January','2018-01-27','$set'),
    ('January','2018-01-28','$sun')  ";
    $forjan3="insert into $table(month,date,day) values
    ('January','2018-01-29','$mon'),
    ('January','2018-01-30','$tue'),
    ('January','2018-01-31','$wed')    ";
    mysqli_query($con,$forjan1);
    mysqli_query($con,$forjan2);
    mysqli_query($con,$forjan3);     // Creading database for january

    
    $forfeb1="insert into $table(month,date,day) values ('$feb','2018-02-01','$thur'), 
    ('$feb','2018-02-02','$fri'),  
    ('$feb','2018-02-03','$set'),  
    ('$feb','2018-02-04','$sun'), 
    ('$feb','2018-02-05','$mon'),
    ('$feb','2018-02-06','$tue'),
    ('$feb','2018-02-07','$wed'),
    ('$feb','2018-02-08','$thur'),
    ('$feb','2018-02-09','$fri'),
    ('$feb','2018-02-10','$set'),
    ('$feb','2018-02-11','$sun'),
    ('$feb','2018-02-12','$mon'),
    ('$feb','2018-02-13','$tue'),
    ('$feb','2018-02-14','$wed') ";
    $forfeb2="insert into $table(month,date,day) values
    ('$feb','2018-02-15','$thur'),
    ('$feb','2018-02-16','$fri'),
    ('$feb','2018-02-17','$set'),
    ('$feb','2018-02-18','$sun'),
    ('$feb','2018-02-19','$mon'),
    ('$feb','2018-02-20','$tue'),
    ('$feb','2018-02-21','$wed'),
    ('$feb','2018-02-22','$thur'),
    ('$feb','2018-02-23','$fri'),
    ('$feb','2018-02-24','$set'),
    ('$feb','2018-02-25','$sun'),
    ('$feb','2018-02-26','$mon'),
    ('$feb','2018-02-27','$tue'),
    ('$feb','2018-02-28','$wed')  ";
    mysqli_query($con,$forfeb1);
    mysqli_query($con,$forfeb2);     //Created database for feb


    $formar1="insert into $table(month,date,day) values
    ('$mar','2018-03-01','$thur'), 
    ('$mar','2018-03-02','$fri'),  
    ('$mar','2018-03-03','$set'),  
    ('$mar','2018-03-04','$sun'), 
    ('$mar','2018-03-05','$mon'),
    ('$mar','2018-03-06','$tue'),
    ('$mar','2018-03-07','$wed'),
    ('$mar','2018-03-08','$thur'),
    ('$mar','2018-03-09','$fri'),
    ('$mar','2018-03-10','$set'),
    ('$mar','2018-03-11','$sun'),
    ('$mar','2018-03-12','$mon'),
    ('$mar','2018-03-13','$tue'),
    ('$mar','2018-03-14','$wed') ";
    $formar2="insert into $table(month,date,day) values
    ('$mar','2018-03-15','$thur'),
    ('$mar','2018-03-16','$fri'),
    ('$mar','2018-03-17','$set'),
    ('$mar','2018-03-18','$sun'),
    ('$mar','2018-03-19','$mon'),
    ('$mar','2018-03-20','$tue'),
    ('$mar','2018-03-21','$wed'),
    ('$mar','2018-03-22','$thur'),
    ('$mar','2018-03-23','$fri'),
    ('$mar','2018-03-24','$set'),
    ('$mar','2018-03-25','$sun'),
    ('$mar','2018-03-26','$mon'),
    ('$mar','2018-03-27','$tue'),
    ('$mar','2018-03-28','$wed')  ";
    $formar3="insert into $table(month,date,day) values
    ('$mar','2018-03-29','$thur'),
    ('$mar','2018-03-30','$fri'),
    ('$mar','2018-03-31','$set')    ";
    mysqli_query($con,$formar1);
    mysqli_query($con,$formar2);
    mysqli_query($con,$formar3);   //Created database for march

    $forapr1="insert into $table(month,date,day) values
    ('$apr','2018-04-01','$sun'), 
    ('$apr','2018-04-02','$mon'),  
    ('$apr','2018-04-03','$tue'),  
    ('$apr','2018-04-04','$wed'), 
    ('$apr','2018-04-05','$thur'),
    ('$apr','2018-04-06','$fri'),
    ('$apr','2018-04-07','$set'),
    ('$apr','2018-04-08','$sun'),
    ('$apr','2018-04-09','$mon'),
    ('$apr','2018-04-10','$tue'),
    ('$apr','2018-04-11','$wed'),
    ('$apr','2018-04-12','$thur'),
    ('$apr','2018-04-13','$fri'),
    ('$apr','2018-04-14','$set') ";
    $forapr2="insert into $table(month,date,day) values
    ('$apr','2018-04-15','$sun'),
    ('$apr','2018-04-16','$mon'),
    ('$apr','2018-04-17','$tue'),
    ('$apr','2018-04-18','$wed'),
    ('$apr','2018-04-19','$thur'),
    ('$apr','2018-04-20','$fri'),
    ('$apr','2018-04-21','$set'),
    ('$apr','2018-04-22','$sun'),
    ('$apr','2018-04-23','$mon'),
    ('$apr','2018-04-24','$tue'),
    ('$apr','2018-04-25','$wed'),
    ('$apr','2018-04-26','$thur'),
    ('$apr','2018-04-27','$fri'),
    ('$apr','2018-04-28','$set')  ";
    $forapr3="insert into $table(month,date,day) values
    ('$apr','2018-04-29','$sun'),
    ('$apr','2018-04-30','$mon')  ";
    mysqli_query($con,$forapr1);
    mysqli_query($con,$forapr2);
    mysqli_query($con,$forapr3);    //Created database for aprail

    $formay1="insert into $table(month,date,day) values 
    ('$may','2018-05-01','$tue'), 
    ('$may','2018-05-02','$wed'),  
    ('$may','2018-05-03','$thur'),  
    ('$may','2018-05-04','$fri'), 
    ('$may','2018-05-05','$set'),
    ('$may','2018-05-06','$sun'),
    ('$may','2018-05-07','$mon'),
    ('$may','2018-05-08','$tue'),
    ('$may','2018-05-09','$wed'),
    ('$may','2018-05-10','$thur'),
    ('$may','2018-05-11','$fri'),
    ('$may','2018-05-12','$set'),
    ('$may','2018-05-13','$sun'),
    ('$may','2018-05-14','$mon') ";
    $formay2="insert into $table(month,date,day) values
    ('$may','2018-05-15','$tue'),
    ('$may','2018-05-16','$wed'),
    ('$may','2018-05-17','$thur'),
    ('$may','2018-05-18','$fri'),
    ('$may','2018-05-19','$set'),
    ('$may','2018-05-20','$sun'),
    ('$may','2018-05-21','$mon'),
    ('$may','2018-05-22','$tue'),
    ('$may','2018-05-23','$wed'),
    ('$may','2018-05-24','$thur'),
    ('$may','2018-05-25','$fri'),
    ('$may','2018-05-26','$set'),
    ('$may','2018-05-27','$sun'),
    ('$may','2018-05-28','$mon')  ";
    $formay3="insert into $table(month,date,day) values
    ('$may','2018-05-29','$tue'),
    ('$may','2018-05-30','$wed'),
    ('$may','2018-05-31','$thur')    ";
    mysqli_query($con,$formay1);
    mysqli_query($con,$formay2);
    mysqli_query($con,$formay3);     //created database for may

    $forjun1="insert into $table(month,date,day) values 
    ('$jun','2018-06-01','$fri'), 
    ('$jun','2018-06-02','$set'),  
    ('$jun','2018-06-03','$sun'),  
    ('$jun','2018-06-04','$mon'), 
    ('$jun','2018-06-05','$tue'),
    ('$jun','2018-06-06','$wed'),
    ('$jun','2018-06-07','$thur'),
    ('$jun','2018-06-08','$fri'),
    ('$jun','2018-06-09','$set'),
    ('$jun','2018-06-10','$sun'),
    ('$jun','2018-06-11','$mon'),
    ('$jun','2018-06-12','$tue'),
    ('$jun','2018-06-13','$wed'),
    ('$jun','2018-06-14','$thur') ";
    $forjun2="insert into $table(month,date,day) values
    ('$jun','2018-06-15','$fri'),
    ('$jun','2018-06-16','$set'),
    ('$jun','2018-06-17','$sun'),
    ('$jun','2018-06-18','$mon'),
    ('$jun','2018-06-19','$tue'),
    ('$jun','2018-06-20','$wed'),
    ('$jun','2018-06-21','$thur'),
    ('$jun','2018-06-22','$fri'),
    ('$jun','2018-06-23','$set'),
    ('$jun','2018-06-24','$sun'),
    ('$jun','2018-06-25','$mon'),
    ('$jun','2018-06-26','$tue'),
    ('$jun','2018-06-27','$wed'),
    ('$jun','2018-06-28','$thur')  ";
    $forjun3="insert into $table(month,date,day) values
    ('$jun','2018-06-29','$fri'),
    ('$jun','2018-06-30','$set')  ";
    mysqli_query($con,$forjun1);
    mysqli_query($con,$forjun2);
    mysqli_query($con,$forjun3);    //Created database for jun


    $forjul1="insert into $table(month,date,day) values 
    ('$jul','2018-07-01','$sun'), 
    ('$jul','2018-07-02','$mon'),  
    ('$jul','2018-07-03','$tue'),  
    ('$jul','2018-07-04','$wed'), 
    ('$jul','2018-07-05','$thur'),
    ('$jul','2018-07-06','$fri'),
    ('$jul','2018-07-07','$set'),
    ('$jul','2018-07-08','$sun'),
    ('$jul','2018-07-09','$mon'),
    ('$jul','2018-07-10','$tue'),
    ('$jul','2018-07-11','$wed'),
    ('$jul','2018-07-12','$thur'),
    ('$jul','2018-07-13','$fri'),
    ('$jul','2018-07-14','$set') ";
    $forjul2="insert into $table(month,date,day) values
    ('$jul','2018-07-15','$sun'),
    ('$jul','2018-07-16','$mon'),
    ('$jul','2018-07-17','$tue'),
    ('$jul','2018-07-18','$wed'),
    ('$jul','2018-07-19','$thur'),
    ('$jul','2018-07-20','$fri'),
    ('$jul','2018-07-21','$set'),
    ('$jul','2018-07-22','$sun'),
    ('$jul','2018-07-23','$mon'),
    ('$jul','2018-07-24','$tue'),
    ('$jul','2018-07-25','$wed'),
    ('$jul','2018-07-26','$thur'),
    ('$jul','2018-07-27','$fri'),
    ('$jul','2018-07-28','$set')  ";
    $forjul3="insert into $table(month,date,day) values
    ('$jul','2018-07-29','$sun'),
    ('$jul','2018-07-30','$mon'),
    ('$jul','2018-07-31','$tue')  ";
    mysqli_query($con,$forjul1);
    mysqli_query($con,$forjul2);
    mysqli_query($con,$forjul3);  //Created database for julay

    $foraug1="insert into $table(month,date,day) values 
    ('$aug','2018-08-01','$wed'), 
    ('$aug','2018-08-02','$thur'),  
    ('$aug','2018-08-03','$fri'),  
    ('$aug','2018-08-04','$set'), 
    ('$aug','2018-08-05','$sun'),
    ('$aug','2018-08-06','$mon'),
    ('$aug','2018-08-07','$tue'),
    ('$aug','2018-08-08','$wed'),
    ('$aug','2018-08-09','$thur'),
    ('$aug','2018-08-10','$fri'),
    ('$aug','2018-08-11','$set'),
    ('$aug','2018-08-12','$sun'),
    ('$aug','2018-08-13','$mon'),
    ('$aug','2018-08-14','$tue') ";
    $foraug2="insert into $table(month,date,day) values
    ('$aug','2018-08-15','$wed'),
    ('$aug','2018-08-16','$thur'),
    ('$aug','2018-08-17','$fri'),
    ('$aug','2018-08-18','$set'),
    ('$aug','2018-08-19','$sun'),
    ('$aug','2018-08-20','$mon'),
    ('$aug','2018-08-21','$tue'),
    ('$aug','2018-08-22','$wed'),
    ('$aug','2018-08-23','$thur'),
    ('$aug','2018-08-24','$fri'),
    ('$aug','2018-08-25','$set'),
    ('$aug','2018-08-26','$sun'),
    ('$aug','2018-08-27','$mon'),
    ('$aug','2018-08-28','$tue')  ";
    $foraug3="insert into $table(month,date,day) values
    ('$aug','2018-08-29','$wed'),
    ('$aug','2018-08-30','$thur'),
    ('$aug','2018-08-31','$fri')  ";
    mysqli_query($con,$foraug1);
    mysqli_query($con,$foraug2);
    mysqli_query($con,$foraug3);   //Created database for aug

    $forsep1="insert into $table(month,date,day) values 
    ('$sep','2018-09-01','$set'), 
    ('$sep','2018-09-02','$sun'),  
    ('$sep','2018-09-03','$mon'),  
    ('$sep','2018-09-04','$tue'), 
    ('$sep','2018-09-05','$wed'),
    ('$sep','2018-09-06','$thur'),
    ('$sep','2018-09-07','$fri'),
    ('$sep','2018-09-08','$set'),
    ('$sep','2018-09-09','$sun'),
    ('$sep','2018-09-10','$mon'),
    ('$sep','2018-09-11','$tue'),
    ('$sep','2018-09-12','$wed'),
    ('$sep','2018-09-13','$thur'),
    ('$sep','2018-09-14','$fri') ";
    $forsep2="insert into $table(month,date,day) values
    ('$sep','2018-09-15','$set'),
    ('$sep','2018-09-16','$sun'),
    ('$sep','2018-09-17','$mon'),
    ('$sep','2018-09-18','$tue'),
    ('$sep','2018-09-19','$wed'),
    ('$sep','2018-09-20','$thur'),
    ('$sep','2018-09-21','$fri'),
    ('$sep','2018-09-22','$set'),
    ('$sep','2018-09-23','$sun'),
    ('$sep','2018-09-24','$mon'),
    ('$sep','2018-09-25','$tue'),
    ('$sep','2018-09-26','$wed'),
    ('$sep','2018-09-27','$thur'),
    ('$sep','2018-09-28','$fri')  ";
    $forsep3="insert into $table(month,date,day) values
    ('$sep','2018-09-29','$set'),
    ('$sep','2018-09-30','$sun') ";
    mysqli_query($con,$forsep1);
    mysqli_query($con,$forsep2);
    mysqli_query($con,$forsep3);  //Created database for september

    $foroct1="insert into $table(month,date,day) values 
    ('$oct','2018-10-01','$mon'), 
    ('$oct','2018-10-02','$tue'),  
    ('$oct','2018-10-03','$wed'),  
    ('$oct','2018-10-04','$thur'), 
    ('$oct','2018-10-05','$fri'),
    ('$oct','2018-10-06','$set'),
    ('$oct','2018-10-07','$sun'),
    ('$oct','2018-10-08','$mon'),
    ('$oct','2018-10-09','$tue'),
    ('$oct','2018-10-10','$wed'),
    ('$oct','2018-10-11','$thur'),
    ('$oct','2018-10-12','$fri'),
    ('$oct','2018-10-13','$set'),
    ('$oct','2018-10-14','$sun') ";
    $foroct2="insert into $table(month,date,day) values
    ('$oct','2018-10-15','$mon'),
    ('$oct','2018-10-16','$tue'),
    ('$oct','2018-10-17','$wed'),
    ('$oct','2018-10-18','$thur'),
    ('$oct','2018-10-19','$fri'),
    ('$oct','2018-10-20','$set'),
    ('$oct','2018-10-21','$sun'),
    ('$oct','2018-10-22','$mon'),
    ('$oct','2018-10-23','$tue'),
    ('$oct','2018-10-24','$wed'),
    ('$oct','2018-10-25','$thur'),
    ('$oct','2018-10-26','$fri'),
    ('$oct','2018-10-27','$set'),
    ('$oct','2018-10-28','$sun')  ";
    $foroct3="insert into $table(month,date,day) values
    ('$oct','2018-10-29','$mon'),
    ('$oct','2018-10-30','$tue'),
    ('$oct','2018-10-31','$wed')    ";
    mysqli_query($con,$foroct1);
    mysqli_query($con,$foroct2);
    mysqli_query($con,$foroct3);  //Creted database for octomber

    $fornov1="insert into $table(month,date,day) values
    ('$nov','2018-11-01','$thur'), 
    ('$nov','2018-11-02','$fri'),  
    ('$nov','2018-11-03','$set'),  
    ('$nov','2018-11-04','$sun'), 
    ('$nov','2018-11-05','$mon'),
    ('$nov','2018-11-06','$tue'),
    ('$nov','2018-11-07','$wed'),
    ('$nov','2018-11-08','$thur'),
    ('$nov','2018-11-09','$fri'),
    ('$nov','2018-11-10','$set'),
    ('$nov','2018-11-11','$sun'),
    ('$nov','2018-11-12','$mon'),
    ('$nov','2018-11-13','$tue'),
    ('$nov','2018-11-14','$wed') ";
    $fornov2="insert into $table(month,date,day) values
    ('$nov','2018-11-15','$thur'),
    ('$nov','2018-11-16','$fri'),
    ('$nov','2018-11-17','$set'),
    ('$nov','2018-11-18','$sun'),
    ('$nov','2018-11-19','$mon'),
    ('$nov','2018-11-20','$tue'),
    ('$nov','2018-11-21','$wed'),
    ('$nov','2018-11-22','$thur'),
    ('$nov','2018-11-23','$fri'),
    ('$nov','2018-11-24','$set'),
    ('$nov','2018-11-25','$sun'),
    ('$nov','2018-11-26','$mon'),
    ('$nov','2018-11-27','$tue'),
    ('$nov','2018-11-28','$wed')  ";
    $fornov3="insert into $table(month,date,day) values
    ('$nov','2018-11-29','$thur'),
    ('$nov','2018-11-30','$fri')  ";
    mysqli_query($con,$fornov1);
    mysqli_query($con,$fornov2);
    mysqli_query($con,$fornov3);  //Created database for november

    $fordec1="insert into $table(month,date,day) values 
    ('$des','2018-09-01','$set'), 
    ('$des','2018-09-02','$sun'),  
    ('$des','2018-09-03','$mon'),  
    ('$des','2018-09-04','$tue'), 
    ('$des','2018-09-05','$wed'),
    ('$des','2018-09-06','$thur'),
    ('$des','2018-09-07','$fri'),
    ('$des','2018-09-08','$set'),
    ('$des','2018-09-09','$sun'),
    ('$des','2018-09-10','$mon'),
    ('$des','2018-09-11','$tue'),
    ('$des','2018-09-12','$wed'),
    ('$des','2018-09-13','$thur'),
    ('$des','2018-09-14','$fri') ";
    $fordec2="insert into $table(month,date,day) values
    ('$des','2018-09-15','$set'),
    ('$des','2018-09-16','$sun'),
    ('$des','2018-09-17','$mon'),
    ('$des','2018-09-18','$tue'),
    ('$des','2018-09-19','$wed'),
    ('$des','2018-09-20','$thur'),
    ('$des','2018-09-21','$fri'),
    ('$des','2018-09-22','$set'),
    ('$des','2018-09-23','$sun'),
    ('$des','2018-09-24','$mon'),
    ('$des','2018-09-25','$tue'),
    ('$des','2018-09-26','$wed'),
    ('$des','2018-09-27','$thur'),
    ('$des','2018-09-28','$fri')  ";
    $fordec3="insert into $table(month,date,day) values
    ('$des','2018-09-29','$set'),
    ('$des','2018-09-30','$sun'),
    ('$des','2018-12-31','$mon') ";
    mysqli_query($con,$fordec1);
    mysqli_query($con,$fordec2);
    mysqli_query($con,$fordec3);   //Created database for december






    if($re==1)
    {
        header('location:conform.php');
    }
    else
    {
        $e="drop table $table";
        mysqli_query($con,$e);
        header('location:erroroccor.php');
    }
}

mysqli_close($con);
?>

